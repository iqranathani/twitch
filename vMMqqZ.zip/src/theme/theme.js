const color = {

    primaryColor: '#274962',
    
    white: '#FFFFFF',
    

  
}
const images = {
    mainLogo: require("../../assets/twitch.jpg"),
    
}
const theme = {
    color,
    images
}
export { theme }